# CLASSES = {'acdc': ['0','1', '2']}
CLASSES = {'acdc': ['0','1']}