CLASSES = {
           
           'fugc': ['background', 'anterior_lip', 'posterior_lip']
           
           }

           