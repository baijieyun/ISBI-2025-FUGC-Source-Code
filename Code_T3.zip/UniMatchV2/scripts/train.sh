#!/bin/bash

# modify these augments if you want to try other datasets, splits or methods
# dataset: ['pascal', 'cityscapes', 'ade20k', 'coco']
# method: ['unimatch_v2', 'fixmatch', 'supervised']
# exp: just for specifying the 'save_path'
# split: ['92', '1_16', ...]. Please check directory './splits/$dataset' for concrete splits
# dataset='pascal'
# method='unimatch_v2'
# exp='dinov2_small'
# split='366'

# config=configs/${dataset}.yaml
# labeled_id_path=splits/$dataset/$split/labeled.txt
# unlabeled_id_path=splits/$dataset/$split/unlabeled.txt
# save_path=exp/$dataset/$method/$exp/$split

# mkdir -p $save_path

# python -m torch.distributed.launch \
#     --nproc_per_node=$1 \
#     --master_addr=localhost \
#     --master_port=$2 \
#     $method.py \
#     --config=$config --labeled-id-path $labeled_id_path --unlabeled-id-path $unlabeled_id_path \
#     --save-path $save_path --port $2 2>&1 | tee $save_path/out.log

#!/bin/bash

dataset='fugc'
method='unimatch_v2'
exp='dinov2_small'

config=/content/drive/MyDrive/MAIA_Work/Thesis/Challenges/FUGC/UniMatch-V2-main/configs/${dataset}.yaml
labeled_id_path=/content/drive/MyDrive/MAIA_Work/Thesis/Challenges/FUGC/UniMatch-V2-main/data/splits/train_l.txt
unlabeled_id_path=/content/drive/MyDrive/MAIA_Work/Thesis/Challenges/FUGC/UniMatch-V2-main/data/splits/train_u.txt
save_path=/content/drive/MyDrive/MAIA_Work/Thesis/Challenges/FUGC/UniMatch-V2-main/exp/$dataset/$method/$exp

mkdir -p $save_path

# Install accelerate (only needed for the first run)
pip install accelerate -q

# Use accelerate for better performance
accelerate launch \
    --multi_gpu \
    --mixed_precision=fp16 \
    $method.py \
    --config=$config --labeled-id-path $labeled_id_path --unlabeled-id-path $unlabeled_id_path \
    --save-path $save_path 2>&1 | tee $save_path/out.log

